package com.scb.nfs.ibank.security.service;

import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.security.vo.OAuthTokenVO;

import java.io.UnsupportedEncodingException;

public interface OAuthService {
    public abstract String getAuthorizeRedirectionUrl(String requestURI, String country) throws UnsupportedEncodingException;
    public abstract OAuthTokenVO getBOUserID(String requestURI, String authorizationCode) throws BusinessException;
}
