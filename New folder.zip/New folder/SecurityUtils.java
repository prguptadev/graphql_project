package com.scb.nfs.ibank.security.utils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.gateway.jsonapi.service.JsonApiService;
import com.scb.nfs.ibank.security.constants.IBankingConstants;
import com.scb.nfs.ibank.security.vo.JsonApiConfigVO;
import com.scb.nfs.ibank.security.vo.OAuthTokenVO;
import com.scb.nfs.ibank.security.vo.OAuthVO;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class SecurityUtils {
    private static Logger logger = LoggerFactory.getLogger(SecurityUtils.class);
    private Map<String, JsonApiConfigVO> oAuthApiServiceConfigMapper;
    private JsonApiService jsonApiService;
    private ObjectMapper objectMapper;
    private String cntry = null;

    public String getAuthorizeRedirectionUrl(String requestURI, String country)throws UnsupportedEncodingException {
        if(StringUtils.isNotBlank(requestURI) && StringUtils.isNotBlank(country)) {
            StringBuffer sb = null;
            cntry = country;
            JsonApiConfigVO oAuthApiConfigVO = oAuthApiServiceConfigMapper.get( IBankingConstants.MFA_OAUTH_SSO_AUTHORIZE_REDIRECT_CONFIG);
            HashMap hmOAuthAPIConfig = oAuthApiConfigVO.getMfaSSOOAuthMapper() != null ? (HashMap) oAuthApiConfigVO.getMfaSSOOAuthMapper().get(country) : null;
            if (null != hmOAuthAPIConfig) {
                sb = new StringBuffer();
                sb.append(hmOAuthAPIConfig.get(IBankingConstants.MFA_authorizeUrl)).append(IBankingConstants.QUESTION_MARK);
                sb.append(IBankingConstants.MFA_client_id).append(IBankingConstants.EQUALS).append(hmOAuthAPIConfig.get(IBankingConstants.MFA_client_id)).append(IBankingConstants.AMPERSAND);
                sb.append(IBankingConstants.MFA_redirect_uri).append(IBankingConstants.EQUALS).append( URLEncoder.encode(hmOAuthAPIConfig.get(IBankingConstants.MFA_redirect_uri).toString(), StandardCharsets.UTF_8.displayName())).append(IBankingConstants.AMPERSAND);
                sb.append(IBankingConstants.MFA_response_type).append(IBankingConstants.EQUALS).append(hmOAuthAPIConfig.get(IBankingConstants.MFA_response_type));
                return  sb.toString();
            }
        }
        return null;
    }

    public OAuthTokenVO getBOUserID(String requestURI,String authorizationCode)throws BusinessException {
        try{
            OAuthVO oAuthVO=null;

            if(StringUtils.isBlank(authorizationCode)  &&  StringUtils.isBlank(requestURI)){
                return null;
            }
            JsonApiConfigVO oAuthApiConfigVO = oAuthApiServiceConfigMapper.get(IBankingConstants.MFA_OAUTH_SSO_ACCESSTOKEN_REDIRECT_CONFIG);
            HashMap hmapOAuthAccessMapper=oAuthApiConfigVO!=null?(oAuthApiConfigVO.getMfaSSOOAuthMapper()!=null?(HashMap) oAuthApiConfigVO.getMfaSSOOAuthMapper().get(cntry):null):null;
            hmapOAuthAccessMapper.replace(IBankingConstants.MFA_Code,authorizationCode);
            String redirect_uri=(String)hmapOAuthAccessMapper.get(IBankingConstants.MFA_redirect_uri);
           if(redirect_uri.contains(requestURI))
                hmapOAuthAccessMapper.replace(IBankingConstants.MFA_redirect_uri,hmapOAuthAccessMapper.get(IBankingConstants.MFA_redirect_uri));
            else
                hmapOAuthAccessMapper.replace(IBankingConstants.MFA_redirect_uri,requestURI+hmapOAuthAccessMapper.get(IBankingConstants.MFA_redirect_uri));

            oAuthApiConfigVO.setMfaSSOAccessMapper(hmapOAuthAccessMapper);
            oAuthApiConfigVO.setCntryCode(cntry);
            oAuthApiConfigVO.setApplicationRequestURI(requestURI);
            oAuthVO =  (OAuthVO) jsonApiService.callJsonApiService(oAuthApiConfigVO);
            return getOAuthTokenVO(oAuthVO);
        } catch(Exception e){
            logger.error("Error while fetching access token"+e);
            return null;
        }
    }

    public Map<String, JsonApiConfigVO> getoAuthApiServiceConfigMapper() {
        return oAuthApiServiceConfigMapper;
    }

    public void setoAuthApiServiceConfigMapper(Map<String, JsonApiConfigVO> oAuthApiServiceConfigMapper) {
        this.oAuthApiServiceConfigMapper = oAuthApiServiceConfigMapper;
    }

    private OAuthTokenVO getOAuthTokenVO(OAuthVO oAuthVO) throws  Exception{
        try {
            if (oAuthVO != null && StringUtils.isNotBlank( oAuthVO.getId_token() )) {
                OAuthTokenVO oAuthTokenVO = null;
                String[] jwt = oAuthVO.getId_token().split( IBankingConstants.STR_SPLIT_DOT );
                byte[] encodedBytes = jwt[1].getBytes();
                Base64.Decoder decoder = Base64.getDecoder();
                byte[] decodedBytes = decoder.decode( encodedBytes );
                objectMapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false );
                oAuthTokenVO = objectMapper.readValue( decodedBytes, OAuthTokenVO.class );
                logger.debug( "Decoded Response Body : " + objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString( oAuthTokenVO ) );
                return oAuthTokenVO;
            }
        }catch (Exception e){
            logger.error( "getOAuthTokenVO ()-Exp" +e);
            return null;
        }
        return null;
    }



    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public void setJsonApiService(JsonApiService jsonApiService) {
        this.jsonApiService = jsonApiService;
    }
}