package com.scb.nfs.ibank.security.service.impl;

import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.security.service.OAuthService;
import com.scb.nfs.ibank.security.utils.SecurityUtils;
import com.scb.nfs.ibank.security.vo.OAuthTokenVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;

public class OAuthServiceImpl implements OAuthService{


    private SecurityUtils serviceUtil;
    private static Logger logger = LoggerFactory.getLogger(OAuthServiceImpl.class);
    public String getAuthorizeRedirectionUrl(String requestURI, String country) throws UnsupportedEncodingException {
        return serviceUtil.getAuthorizeRedirectionUrl(requestURI,country);
    }
    public OAuthTokenVO getBOUserID(String requestURI, String authorizationCode)throws BusinessException {
        return serviceUtil.getBOUserID(requestURI,authorizationCode);
    }

    public SecurityUtils getServiceUtil() {
        return serviceUtil;
    }

    public void setServiceUtil(SecurityUtils serviceUtil) {
        this.serviceUtil = serviceUtil;
    }
}
