package com.scb.nfs.ibank.security.constants;

public interface ConfigConstants {


    public static final String CONST_Y = "Y";
    public static final String IBANK_PROPS_CONFIG_KEY = "ibank.properties";
    public static final String DEFAULT_COUNTRY_CODE = "default.country.code";
    public static final String MFA_COUNTRY_CODE = "mfa.country.code";


}