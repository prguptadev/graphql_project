package com.scb.nfs.ibank.security.bo;

import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.security.vo.OAuthTokenVO;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

public interface OAuthBO {
    public abstract String getRedirectURL(HttpServletRequest httpRequest) throws UnsupportedEncodingException;
    public abstract OAuthTokenVO getBOUserID(HttpServletRequest request) throws BusinessException;
}
