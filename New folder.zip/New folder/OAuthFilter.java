package com.scb.nfs.ibank.common.web.helper;


import com.scb.nfs.base.config.ConfigurationManager;
import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.base.helper.BaseConstant;
import com.scb.nfs.base.helper.BeanFactory;
import com.scb.nfs.ibank.security.bo.OAuthBO;
import com.scb.nfs.ibank.security.constants.ConfigConstants;
import com.scb.nfs.ibank.security.constants.IBankingConstants;
import com.scb.nfs.ibank.security.vo.OAuthTokenVO;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import static com.scb.nfs.ibank.security.constants.IBankingConstants.ERROR_CODE_ONE;

public class OAuthFilter implements Filter {

    private static Logger log = LoggerFactory.getLogger(OAuthFilter.class);
    private static final String LOGIN_URL_JE = "/ibank/je/boa/login.htm";
    private static final String MFA_REDIRECTION_URL="/ibank/je/boa/landing.htm";
    private static int mfaAccessCounter=0;
    private static boolean mfaRedirectFlag;


    public OAuthFilter() { }

    public void destroy() {
        log.debug("destroy:");
    }


    // MFA changes
    public String getRedirectURL(HttpServletRequest httpRequest) throws UnsupportedEncodingException {
        OAuthBO oAuthBO = (OAuthBO) BeanFactory.getBean("oAuthBO");
        return oAuthBO.getRedirectURL(httpRequest);
    }


    public OAuthTokenVO getAccessToken(HttpServletRequest httpRequest)throws BusinessException {
        OAuthBO oAuthBO = (OAuthBO) BeanFactory.getBean("oAuthBO");
        return oAuthBO.getBOUserID(httpRequest);
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String uri = httpRequest.getRequestURL().toString().replace( LOGIN_URL_JE,"" );
        HttpSession session;
        OAuthTokenVO oAuthTokenVO=null;
        try {
            mfaRedirectFlag=true;
            String queryParam = httpRequest.getQueryString();
            String servletPath = httpRequest.getServletPath();
            session=httpRequest.getSession(false);
            if(null!=session && null!=session.getAttribute( IBankingConstants.MFA_STATUS)){
                mfaRedirectFlag=false;
            }
            if(null!=servletPath && servletPath.contains(LOGIN_URL_JE) && mfaRedirectFlag && queryParam == null){
               mfaAccessCounter++;
               httpResponse.sendRedirect(getRedirectURL(httpRequest));
            }else if(null!=queryParam && servletPath.contains(MFA_REDIRECTION_URL)) {
                oAuthTokenVO = getAccessToken( httpRequest );
                log.info( "oAuthTokenVO---- {}" + oAuthTokenVO );
                if (oAuthTokenVO != null && StringUtils.isNotBlank( oAuthTokenVO.getBankId() )) {
                    session = httpRequest.getSession( true );
                    session.setAttribute( IBankingConstants.MFA_ACTIVATED, IBankingConstants.MFA_ACTIVATED_STATUS_A );
                    session.setAttribute( IBankingConstants.MFA_USER_BANK_ID, oAuthTokenVO.getBankId() );
                    session.setAttribute( IBankingConstants.MFA_USER_FIRSTNAME, oAuthTokenVO.getFamilyName() );
                    session.setAttribute( IBankingConstants.MFA_USER_SECONDNAME, oAuthTokenVO.getGivenName() );
                    session.setAttribute( IBankingConstants.MFA_ENABLED_FLAG, true );
                    session.setAttribute( IBankingConstants.MFA_STATUS, IBankingConstants.MFA_STATUS_SUCCESS );
                    String contextPath = httpRequest.getContextPath();
                    String new_uri = httpRequest.getRequestURL().toString().replace( httpRequest.getRequestURI(), "" );
                    httpResponse.sendRedirect( new_uri + contextPath + LOGIN_URL_JE );
                    return;
                } else {
                    session = httpRequest.getSession( true );
                    session.setAttribute( IBankingConstants.MFA_ENABLED_FLAG, true );
                    session.setAttribute( IBankingConstants.MFA_STATUS, IBankingConstants.MFA_STATUS_FAIL );
                    String contextPath = httpRequest.getContextPath();
                    String new_uri = httpRequest.getRequestURL().toString().replace( httpRequest.getRequestURI(), "" );
                    httpResponse.sendRedirect( new_uri + contextPath + LOGIN_URL_JE );
                    clearMfaCookies(httpRequest,httpResponse);
                    return;
                }
            }else if(servletPath.contains(LOGIN_URL_JE)  && queryParam == ERROR_CODE_ONE){
                session = httpRequest.getSession( true );
                session.setAttribute( IBankingConstants.MFA_ENABLED_FLAG, true );
                session.setAttribute( IBankingConstants.MFA_STATUS, IBankingConstants.MFA_STATUS_FAIL );
                String contextPath = httpRequest.getContextPath();
                String new_uri = httpRequest.getRequestURL().toString().replace( httpRequest.getRequestURI(), "" );
                httpResponse.sendRedirect( new_uri + contextPath + LOGIN_URL_JE );
                clearMfaCookies(httpRequest,httpResponse);
                return;
            }else{
                mfaAccessCounter=0;
            }

            chain.doFilter(httpRequest, httpResponse);
        } catch (Exception e) {
            log.error("OAuthFilter inside exception", e);
        } finally {
            if (log.isDebugEnabled())
                log.debug("[OAuthFilter: finally]");
        }
        
    }

    public void init(FilterConfig filterConfig) throws ServletException {
        mfaAccessCounter=0;
        log.info("init:");
    }


    public static boolean isFeatureEnabled(String cntryCode,String featureName){

        if(StringUtils.isNotBlank(cntryCode) && StringUtils.isNotBlank( ConfigurationManager.getProperty(ConfigConstants.IBANK_PROPS_CONFIG_KEY, featureName))) {
            String [] cntryCodesEnabled=ConfigurationManager.getProperty(ConfigConstants.IBANK_PROPS_CONFIG_KEY,featureName).split(",");
            return ArrayUtils.contains(cntryCodesEnabled,cntryCode);
        }
        return false;
    }

    public void clearMfaCookies(HttpServletRequest request,HttpServletResponse response){
        Cookie[] cookies = request.getCookies();
        if (cookies != null)
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals( "iPlanetDirectoryPro" )) {
                    cookie.setMaxAge( 0 );
                    response.addCookie( cookie );
                    break;
                }
            }

    }



}