package com.scb.nfs.ibank.security.bo.impl;

import com.scb.nfs.base.config.ConfigurationManager;
import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.security.bo.OAuthBO;
import com.scb.nfs.ibank.security.constants.ConfigConstants;
import com.scb.nfs.ibank.security.constants.IBankingConstants;
import com.scb.nfs.ibank.security.service.OAuthService;
import com.scb.nfs.ibank.security.vo.OAuthTokenVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

public class OAuthBOImpl implements OAuthBO {

    private static Logger logger = LoggerFactory.getLogger( OAuthBOImpl.class );
    private OAuthService oAuthService;
    private static final String LOGIN_URL_JE = "/ibank/je/boa/login.htm";


    public String getRedirectURL(HttpServletRequest httpRequest) throws UnsupportedEncodingException {
        String requestURI = null;
        String country = null;
        if (null != httpRequest) {
            requestURI = httpRequest.getRequestURL() != null ? httpRequest.getRequestURL().toString().replace( LOGIN_URL_JE,"" ) : null;
            String [] cntryCodesEnabled= ConfigurationManager.getProperty( ConfigConstants.IBANK_PROPS_CONFIG_KEY,ConfigConstants.MFA_COUNTRY_CODE).split(",");
            country = cntryCodesEnabled[0];
        }
        return oAuthService.getAuthorizeRedirectionUrl( requestURI, country );
    }

    public OAuthTokenVO getBOUserID(HttpServletRequest request) throws BusinessException {
        String requestURI = null;
        String authorizationCode = null;
        if (null != request) {

            requestURI = request.getRequestURL() != null ? request.getRequestURL().toString().replace( LOGIN_URL_JE,"" ) : null;
            authorizationCode = request.getParameter( IBankingConstants.MFA_Code );
        }
        return oAuthService.getBOUserID( requestURI, authorizationCode );
    }


    public void setoAuthService(OAuthService oAuthService) {
        this.oAuthService = oAuthService;
    }
}
