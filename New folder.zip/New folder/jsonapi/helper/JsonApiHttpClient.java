package com.scb.nfs.ibank.gateway.jsonapi.helper;

import com.scb.nfs.base.exception.AdapterException;
import com.scb.nfs.base.helper.ErrorConstant;
import com.scb.nfs.ibank.security.constants.IBankingConstants;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.ResourceUtils;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.net.SocketTimeoutException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class JsonApiHttpClient {
    private String trustStorePassword;
    private String trustStorePath;
    private String trustStoreType;
    private String encodedCert;
    private String alias;
    private static Logger logger = LoggerFactory.getLogger(JsonApiHttpClient.class);


    public String post(String endpoint, int timeout, Map<String, String> httpHeader, Map<String, String> requestParams) throws AdapterException,Exception {
        HttpPost httpPost = new HttpPost(endpoint);
        addHeaders(httpPost, httpHeader);
        addRequestParams(httpPost, requestParams);
        logger.info("JsonApiHttpClient-Inside-post:endpoint: {}"+endpoint+":Timeout:{}"+timeout+":httpHeader:{}"+httpHeader+"requestParams:{}"+requestParams);
        return execute(endpoint, httpPost, timeout);
    }


    private void addHeaders(HttpRequestBase httpMethod, Map<String, String> headers) throws Exception {
        if(headers != null && !headers.isEmpty()){
            headers.replace( IBankingConstants.STR_X_CERT,retrieveAndEncodeCert());
            for (String headerName : headers.keySet())
                httpMethod.setHeader( headerName, headers.get( headerName ) );
        }
    }

    private void addRequestParams(HttpPost httpPost, Map<String, String> requestParams) throws AdapterException {
        try {
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            if (requestParams != null && !requestParams.isEmpty()) {
                for (String requestParam : requestParams.keySet()) {
                    params.add(new BasicNameValuePair(requestParam, requestParams.get(requestParam)));
                }
                httpPost.setEntity(new UrlEncodedFormEntity(params));
            }
        } catch (UnsupportedEncodingException ue) {
            logger.error("JsonApiHttpClient- ue"+ue);
            throw new AdapterException(ErrorConstant.ERR_INT_INVALID_PARAM, "Invalid params.", ue);
        } catch (Exception e) {
            logger.error("JsonApiHttpClient- Exception"+e);
            throw new AdapterException(ErrorConstant.ERR_INT_INVALID_PARAM, "Invalid params.", e);
        }
    }


    //httpclient call for get authToken , not in used currently , alternative way for CloseableHttpResponse
    public String getIAMToken(String endpoint, int timeout, Map<String, String> httpHeader, Map<String, String> requestParams) {

        HttpClient localHttpClient = null;
        try {
            logger.info("Calling IAM to get the token");
            localHttpClient = new HttpClient();
            localHttpClient.getHttpConnectionManager().getParams().setConnectionTimeout(timeout);
            localHttpClient.getHttpConnectionManager().getParams().setSoTimeout(timeout);


            PostMethod localPostMethod = new PostMethod(endpoint);
            localPostMethod.addRequestHeader(IBankingConstants.STR_CONTENTTYPE, "application/x-www-form-urlencoded;charset=utf-8");
            localPostMethod.addRequestHeader(IBankingConstants.STR_X_CERT, retrieveAndEncodeCert());
            localPostMethod.addParameter( "client_id",requestParams.get("client_id") );
            localPostMethod.addParameter( "redirect_uri",requestParams.get("redirect_uri") );
            localPostMethod.addParameter( "code",requestParams.get("code") );
            localPostMethod.addParameter( "grant_type",requestParams.get("grant_type") );

            int i = localHttpClient.executeMethod(localPostMethod);
            if (i != 200) {
                logger.error("[submitPostBody: IAM url, statusCode]=" + endpoint + "," + i);
            } else {
                logger.info("[submitPostBody: IAM url, statusCode]=" + endpoint + "," + i);
            }

            return  localPostMethod.getResponseBodyAsString();


        } catch (Exception localException) {
            logger.error("Error while getting response from IAM :: {} ",localException);
        } finally {
            try {
                HttpConnectionManager localHttpConnectionManager = localHttpClient.getHttpConnectionManager();
                if ((localHttpConnectionManager instanceof SimpleHttpConnectionManager)) {
                    ((SimpleHttpConnectionManager) localHttpConnectionManager).shutdown();
                }
            } catch (Throwable localThrowable) {
                logger.error("Unable to shutdown HttpConnectionManager!", localThrowable);
            }
        }
        return null;
    }

    private String execute(String url, HttpUriRequest request, int timeout) throws AdapterException {
        logger.info("Execute"+url);
        CloseableHttpClient client = createClientWithCustomSSLContext(timeout);
        long startTime = System.currentTimeMillis();
        try {
            CloseableHttpResponse response = client.execute(request);
            return EntityUtils.toString(response.getEntity());
        } catch (SocketTimeoutException ste) {
            logger.error("JsonApiHttpClient- SocketTimeoutException"+ste);
            throw new AdapterException(ErrorConstant.ERR_INT_TIMEOUT, "SocketTimeoutException", ste);
        } catch (Exception e) {
            logger.error("JsonApiHttpClient- Exception"+e);
            throw new AdapterException(ErrorConstant.ERR_INT_CONNECTION_ERROR, "Exception error", e);
        } finally {
            closeQuietly(client);
            long endTime = System.currentTimeMillis();
        }

    }
    private CloseableHttpClient createClient(int timeout) {
        return HttpClients.custom()
                .useSystemProperties()
                .setDefaultRequestConfig(createTimeoutConfiguration(timeout)).build();

    }

    private RequestConfig createTimeoutConfiguration(int timeout) {
        return RequestConfig.custom().setSocketTimeout(timeout)
                .setConnectTimeout(timeout)
                .setConnectionRequestTimeout(timeout).build();
    }

    private CloseableHttpClient createClientWithCustomSSLContext(int timeout) {
        HttpClientBuilder clientbuilder = HttpClients.custom();
        clientbuilder.useSystemProperties().setDefaultRequestConfig(createTimeoutConfiguration(timeout));
        //clientbuilder.setDefaultHeaders(createHeaders());
        clientbuilder.setSSLSocketFactory(getCustomSSLConnectionSocketFactory());
        return clientbuilder.build();
    }

    private SSLConnectionSocketFactory getCustomSSLConnectionSocketFactory(){
        try{
            logger.info("trustStorePath--"+trustStorePath+":trustStorePassword:"+trustStorePassword+":trustaliasName:"+alias);
            SSLContextBuilder SSLBuilder = SSLContexts.custom();
            if (StringUtils.isNotBlank(trustStorePath) && StringUtils.isNotBlank(trustStorePassword) ) {
                if(StringUtils.isBlank(trustStoreType)){
                    trustStoreType = IBankingConstants.STR_JKS;
                }
                SSLBuilder = SSLBuilder.loadTrustMaterial(getTrustStore(trustStorePath, trustStorePassword, trustStoreType));
            }

            SSLContext sslcontext = SSLBuilder.build();
            SSLConnectionSocketFactory sslConSocFactory = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1","TLSv1.1","TLSv1.2" }, null, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            return sslConSocFactory;

        }catch(Exception e){
            logger.error("getCustomSSLConnectionSocketFactory Inside Exception--"+e);
        }
        return null;
    }

    private KeyStore getTrustStore(String trustStoreLocation, String trustStorePassword, String trustStoreFormat) throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableKeyException {
        final KeyStore trustStore = KeyStore.getInstance(trustStoreFormat);
        if (trustStoreLocation.startsWith(ResourceUtils.CLASSPATH_URL_PREFIX)) {
            String classPathLocation = trustStoreLocation.substring(ResourceUtils.CLASSPATH_URL_PREFIX.length());
            ClassPathResource resource = new ClassPathResource(classPathLocation);
            InputStream inputStream = resource.getInputStream();
            trustStore.load(inputStream, trustStorePassword.toCharArray());
            inputStream.close();
        } else {
            FileInputStream fileInputStream = new FileInputStream(trustStoreLocation);
            trustStore.load(fileInputStream, trustStorePassword.toCharArray());
            fileInputStream.close();
        }
        return trustStore;
    }
    private void closeQuietly(Closeable closeable) throws AdapterException {
        if (closeable == null)
            return;
        try {
            closeable.close();
        } catch (Exception ignore) {
            throw new AdapterException(ErrorConstant.ERR_INT_CONNECTION_ERROR, "Unable to release connection.", ignore);
        }
    }

    public String retrieveAndEncodeCert() throws Exception {
        try {
            File file = new File(trustStorePath);
            FileInputStream in = new FileInputStream(file);
            KeyStore ks = KeyStore.getInstance(IBankingConstants.STR_JKS);
          // KeyStore ks = KeyStore.getInstance(IBankingConstants.STR_CER);
            ks.load(in, trustStorePassword.toCharArray());
            in.close();
            Certificate cert = ks.getCertificate(alias);
            encodedCert = new String(Base64.encodeBase64(cert.getEncoded()), IBankingConstants.CHAR_UTF_8);
        }catch (NoSuchAlgorithmException nse) {
            logger.error("NoSuchAlgorithmException while creating SSL Context : "+nse);
        } catch (CertificateException ce) {
            logger.error("CertificateException while creating SSL Context : "+ce);
        } catch (KeyStoreException kse) {
            logger.error("KeyStoreException while creating SSL Context : "+kse);
        } catch (IOException ie) {
            logger.error("IOException while creating SSL Context : "+ie);
        }
        return encodedCert;
    }

    public void setTrustStorePath(String trustStorePath) {
        this.trustStorePath = trustStorePath;
    }

    public void setTrustStorePassword(String trustStorePassword) {
        this.trustStorePassword = trustStorePassword;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }


}