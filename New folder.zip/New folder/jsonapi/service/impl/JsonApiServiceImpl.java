package com.scb.nfs.ibank.gateway.jsonapi.service.impl;

import com.scb.nfs.base.exception.AdapterException;
import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.gateway.jsonapi.helper.JsonApiGateway;
import com.scb.nfs.ibank.gateway.jsonapi.service.JsonApiService;
import com.scb.nfs.ibank.security.vo.JsonApiConfigVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsonApiServiceImpl implements JsonApiService {

	private JsonApiGateway jsonApiGateway;
	private static Logger logger = LoggerFactory.getLogger(JsonApiServiceImpl.class);

	public Object callJsonApiService(JsonApiConfigVO configVO) throws BusinessException{
		try {
			return jsonApiGateway.invoke(configVO);
		}catch(AdapterException ae){
			logger.error("AdapterException -"+ae);
			throw new BusinessException(ae.getErrorCode(), ae);
		}catch(BusinessException be){
			logger.error("BusinessException -"+be);
			throw new BusinessException(be.getErrorCode(), be);
		}
	}
	public void setJsonApiGateway(JsonApiGateway jsonApiGateway) {

		this.jsonApiGateway = jsonApiGateway;
	}
}
