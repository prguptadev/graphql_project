package com.scb.nfs.ibank.security.vo;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Map;

public class JsonApiConfigVO implements Serializable{

	private static final long serialVersionUID = 1L;
	private Map<String, Map<String,String>> mfaSSOOAuthMapper;
	private Integer timeout;
	private JsonApiConfigVO apiTokenServiceConfigVO;
	private Map<String, String> httpHeaderMap;
//	private Map<String, String> httpRequestParamMap;
	private String responseClass;
	private String requestType;
	private String serviceName;
	private String cntryCode;
	private String retrieveEncodeCert;
	private String accessTokenUrl;
	private Map<String,String> mfaSSOAccessMapper;
	private String applicationRequestURI;


	public Map<String, String> getHttpHeaderMap() {
		return httpHeaderMap;
	}

	public void setHttpHeaderMap(Map<String, String> httpHeaderMap) {
		this.httpHeaderMap = httpHeaderMap;
	}


	public Map<String, Map<String,String>> getMfaSSOOAuthMapper() {
		return mfaSSOOAuthMapper;
	}

	public void setMfaSSOOAuthMapper(Map<String, Map<String,String>> mfaSSOOAuthMapper) {
		this.mfaSSOOAuthMapper = mfaSSOOAuthMapper;
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

	public JsonApiConfigVO getApiTokenServiceConfigVO() {
		return apiTokenServiceConfigVO;
	}

	public void setApiTokenServiceConfigVO(JsonApiConfigVO apiTokenServiceConfigVO) {
		this.apiTokenServiceConfigVO = apiTokenServiceConfigVO;
	}


	public String toString() {
		return ReflectionToStringBuilder.toString(this,
				ToStringStyle.SHORT_PREFIX_STYLE);
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getResponseClass() {
		return responseClass;
	}

	public void setResponseClass(String responseClass) {
		this.responseClass = responseClass;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getCntryCode() {
		return cntryCode;
	}

	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}

	public String getRetrieveEncodeCert() {
		return retrieveEncodeCert;
	}

	public void setRetrieveEncodeCert(String retrieveEncodeCert) {
		this.retrieveEncodeCert = retrieveEncodeCert;
	}

	public Map<String, String> getMfaSSOAccessMapper() {
		return mfaSSOAccessMapper;
	}

	public void setMfaSSOAccessMapper(Map<String, String> mfaSSOAccessMapper) {
		this.mfaSSOAccessMapper = mfaSSOAccessMapper;
	}

	public String getAccessTokenUrl() {
		return accessTokenUrl;
	}

	public void setAccessTokenUrl(String accessTokenUrl) {
		this.accessTokenUrl = accessTokenUrl;
	}

	public String getApplicationRequestURI() {
		return applicationRequestURI;
	}

	public void setApplicationRequestURI(String applicationRequestURI) {
		this.applicationRequestURI = applicationRequestURI;
	}
}
