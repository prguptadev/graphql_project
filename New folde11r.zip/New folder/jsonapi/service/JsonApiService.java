package com.scb.nfs.ibank.gateway.jsonapi.service;

import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.ibank.security.vo.JsonApiConfigVO;


public interface JsonApiService
{
   public Object callJsonApiService(JsonApiConfigVO configVO) throws BusinessException;
}
