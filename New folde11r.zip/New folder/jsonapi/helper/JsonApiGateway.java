package com.scb.nfs.ibank.gateway.jsonapi.helper;

import com.google.gson.Gson;
import com.scb.nfs.base.exception.AdapterException;
import com.scb.nfs.base.exception.BusinessException;
import com.scb.nfs.base.helper.ErrorConstant;
import com.scb.nfs.ibank.security.constants.IBankingConstants;
import com.scb.nfs.ibank.security.vo.JsonApiConfigVO;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JsonApiGateway {
    private Gson gson;
    private JsonApiHttpClient jsonApiHttpClient;
    private static Logger logger = LoggerFactory.getLogger(JsonApiGateway.class);

    public Object invoke(JsonApiConfigVO configVo) throws BusinessException, AdapterException {
        Object obj = null;
        try {
            if (null!=configVo && StringUtils.equalsIgnoreCase(configVo.getRequestType(), IBankingConstants.STR_POST_METHOD)) {
                if (configVo.getMfaSSOOAuthMapper() != null) {
                    String res = null;
                   res = jsonApiHttpClient.post(configVo.getAccessTokenUrl(), configVo.getTimeout(), configVo.getHttpHeaderMap(), configVo.getMfaSSOAccessMapper());
                  obj = gson.fromJson(res, Class.forName(configVo.getResponseClass()));
                }
            }
        }catch (AdapterException ae) {
            logger.error("JsonApiGateway --invoke AdapterException:"+ae);
            throw ae;
        } catch (Exception e) {
            logger.error("JsonApiGateway --invoke Exception:"+e);
            throw new AdapterException(ErrorConstant.ERR_INT_CONFIG_ERROR, "invalid config.", e);
        }
        return obj;
    }
    public void setJsonApiHttpClient(JsonApiHttpClient jsonApiHttpClient) {
        this.jsonApiHttpClient = jsonApiHttpClient;
    }


    public void setGson(Gson gson) {
        this.gson = gson;
    }

}